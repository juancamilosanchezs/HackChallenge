from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('importar/', views.importar_datos, name='importar_datos'),
]