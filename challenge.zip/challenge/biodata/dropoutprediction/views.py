
from .forms import *
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from .models import *
from openpyxl import load_workbook
from collections import Counter
from statistics import mean
from openpyxl import load_workbook
import joblib
import pandas as pd
import joblib
import warnings
from .Prediction_College import realizar_prediccion

def importar_datos(request):
    if request.method == 'POST':
        form = ImportarDatosForm(request.POST, request.FILES)
        if form.is_valid():
            archivo_excel = form.cleaned_data['archivo_excel']
            print(archivo_excel)
            df = pd.read_excel(archivo_excel).iloc[:,1]
            modelo = joblib.load('dropoutprediction/randomforest.pkl')
            predicciones = modelo.predict([df])
            for prediccion in predicciones:
                print("Predicción:", prediccion)

            return redirect('importar_datos')


        else:
            print("no valido")# Redirige a la página de importación de datos
    else:
        form = ImportarDatosForm()
    return render(request, 'app/index.html', {'form': form})


            