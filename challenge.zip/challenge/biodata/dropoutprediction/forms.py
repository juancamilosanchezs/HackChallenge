from django.contrib.auth.forms import AuthenticationForm
from django import forms
from .models import *

class ImportarDatosForm(forms.Form):
    archivo_excel = forms.FileField(label='Seleccionar archivo Excel')