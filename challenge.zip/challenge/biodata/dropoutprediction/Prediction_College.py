import joblib
import pandas as pd

def realizar_prediccion(input_data):
        modelo = joblib.load('dropoutprediction/randomforest.pkl')
        predicciones = modelo.predict(input_data)
        for prediccion in predicciones:
            print("Predicción:", prediccion)
